def getTotalScore(name,dic):
    try:
        return sum(dic[name])
    except Exception:
        print('Name not found')
        return 0
import csv

def part2():
    counter = 0
    d = {}
    with open('grade.csv','r',newline='') as file:
        reader = csv.reader(file)
        header = file.readline()
        for line in reader:
            t = []
            for grades in line[1:]:
                try:
                    t.append(float(grades))
                except Exception:
                    counter += 1
                    t.append(0.0)
            d[line[0]] = t
    print('Total non-numeric grades: ',counter)
    with open('gradedGrades.csv','w',newline='') as outfile:
        writer = csv.writer(outfile)
        writer.writerow(header.split(','))
        for k in d:
            writer.writerow((k,*d[k]))
    return d
dd = part2()
print('Name that exists ',getTotalScore('Au, Ted',dd))
print('Name that doesnt exist ',getTotalScore('Bob,Dylan',dd))
