import peep
import poop
def main():
    user = input("Enter plain text: ")
    choice = input("Press R | r for random key or enter: ")
    poop.work(user,choice)
    print(' ')
    user = input("Enter area code: ")
    peep.work(user)
main()
'''
=========== RESTART: /Users/cptnbread/Desktop/Python/project2TB.py ===========
Enter plain text: face blow
Press R | r for random key or enter: 
  face  --> obzg   blow  --> psiy  
Enter area code: 
>>> 
=========== RESTART: /Users/cptnbread/Desktop/Python/project2TB.py ===========
Enter plain text: face blow
Press R | r for random key or enter: r
Key:  uhgilasbyvkrepmzcqdotfjnxw
  face  --> augl   blow  --> hrmj  
Enter area code: 
>>> 
=========== RESTART: /Users/cptnbread/Desktop/Python/project2TB.py ===========
Enter plain text: wonderful python java doedlugvusu
Press R | r for random key or enter: 
  wonderful  --> yikhguoes   python  --> mxnvik   java  --> dbrb   doedlugvusu  --> highsecrete  
Enter area code: 
>>> 
=========== RESTART: /Users/cptnbread/Desktop/Python/project2TB.py ===========
Enter plain text: wonderful python java doedlugvusu
Press R | r for random key or enter: r
Key:  sadhqnjwocmktierupxbyglvfz
  wonderful  --> leihqpnyk   python  --> rfbwei   java  --> csgs   doedlugvusu  --> heqhkyjgyxy  
Enter area code: 
>>> 

'''
